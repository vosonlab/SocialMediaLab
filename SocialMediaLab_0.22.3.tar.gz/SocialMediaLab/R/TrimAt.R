TrimAt <-
function(x) {
  # remove @ from text

  sub('@', '', x)
}
