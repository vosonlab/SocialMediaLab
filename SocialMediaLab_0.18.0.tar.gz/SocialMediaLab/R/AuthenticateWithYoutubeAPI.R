AuthenticateWithYoutubeAPI <-
function(apiKeyYoutube) {

  return(apiKeyYoutube)

}
